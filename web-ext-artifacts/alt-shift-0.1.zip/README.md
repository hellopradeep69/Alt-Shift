## Alt-shift [Indented for personal use only]

<img src="assests/alt1.png" alt="OS-Roulette"  style="  display: block; margin-left: auto; margin-right: auto; width: 50%;">

----------
- Move the current Firefox tab to the desired tab number
- Press Alt+shift+1 to move tab to Tab number one and likewise
- Alt+shift+1 to Alt+shift+5 are available . If you need more five that means you are not
    using your browser properly.

### reference
----------
[Move tab](https://github.com/jmmerz/move-tab-hotkeys)
[Firefox developer Guide](https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/)
